<!--Muhammad Pajar_932020043_2TE2-->
<?php

$sname= "localhost";
$unmae= "root";
$password = "";

$db_name = "login_page";

$conn = mysqli_connect($sname, $unmae, $password, $db_name);